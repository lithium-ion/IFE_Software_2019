# SD_HAL_MPU6050
Running MPU6050 with HAL drivers
