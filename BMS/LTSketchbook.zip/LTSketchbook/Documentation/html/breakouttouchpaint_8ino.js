var breakouttouchpaint_8ino =
[
    [ "loop", "breakouttouchpaint_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "breakouttouchpaint_8ino.html#a635bebcf1bdfa7de6f25c21a01451d64", null ],
    [ "BOXSIZE", "breakouttouchpaint_8ino.html#a4f84c7cd953e90b218a9baa12f6e5e35", null ],
    [ "MAXPRESSURE", "breakouttouchpaint_8ino.html#a4a6e2948ffa5d35d9d934d7b875abd4c", null ],
    [ "MINPRESSURE", "breakouttouchpaint_8ino.html#a42a8c4982cef9a6a4b0c4120e95f33da", null ],
    [ "PENRADIUS", "breakouttouchpaint_8ino.html#a7c7791e29a4d4da8046b200fb4dc742a", null ],
    [ "TFT_CS", "breakouttouchpaint_8ino.html#a5f4d46ae101b77df78010c506601c87c", null ],
    [ "TFT_DC", "breakouttouchpaint_8ino.html#a51529307207622c113ff0d584536be13", null ],
    [ "TS_MAXX", "breakouttouchpaint_8ino.html#ae0c07334a8bec0889ce72fd7cd207000", null ],
    [ "TS_MAXY", "breakouttouchpaint_8ino.html#a8037be4206d706c1077d0153db12690a", null ],
    [ "TS_MINX", "breakouttouchpaint_8ino.html#a33c25be9eca2247ac244fc928183eb55", null ],
    [ "TS_MINY", "breakouttouchpaint_8ino.html#a221886aabcdfcc6e096414db04cfbdb9", null ],
    [ "XM", "breakouttouchpaint_8ino.html#aba9214664551147170071ccde26b1366", null ],
    [ "XP", "breakouttouchpaint_8ino.html#a328016c95889e9831b2606769b90a317", null ],
    [ "YM", "breakouttouchpaint_8ino.html#a517c4f2440d1d36aa90f125d4b7e12f5", null ],
    [ "YP", "breakouttouchpaint_8ino.html#ab7dd464b7c1c7ae1fe3b51487a226c80", null ],
    [ "currentcolor", "breakouttouchpaint_8ino.html#a272870a56ba53cb422f9193dad97f9d3", null ],
    [ "oldcolor", "breakouttouchpaint_8ino.html#ab98b07936cc8e82a95130dea7b6c9cd5", null ],
    [ "tft", "breakouttouchpaint_8ino.html#a41c3eb6bc5901609f9f976b594e5089f", null ],
    [ "ts", "breakouttouchpaint_8ino.html#a3c2f79ac35b86b8495c8ad7f5294d73f", null ]
];