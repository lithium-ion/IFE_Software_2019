var classLT__PMBusDeviceLTC2980 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC2980.html#a939f703f5901c74896b2760b18623aa3", null ],
    [ "detect", "classLT__PMBusDeviceLTC2980.html#a8f9374b4cfa757161aff1a26cc2feea4", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC2980.html#a69166586d307090623cc652ce876d830", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC2980.html#a8d8a9c79c0c39e0197f9c17bbb559b60", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC2980.html#a9d6563e3a164f586cee6522cf3a97183", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC2980.html#a0baf1ccdaaac77d7f978ec8b2b4e0105", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC2980.html#acb23c43825727c2cd34c644a347bea3c", null ],
    [ "getType", "classLT__PMBusDeviceLTC2980.html#a1cf21a374062dca04594f2a0be324ebb", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC2980.html#a87a13484b1716ed347d671c9faf7ff5c", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC2980.html#aa1193a59a0b55056c7ba708c6debd473", null ],
    [ "LT_PMBusDeviceLTC2980", "classLT__PMBusDeviceLTC2980.html#ab733d78c36bedec093190e4e240a4ab4", null ],
    [ "cap_", "classLT__PMBusDeviceLTC2980.html#a0cf860e14ec21a8ebf1370d8c82529fa", null ]
];