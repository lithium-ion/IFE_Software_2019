var classLT__PMBusDeviceLTM4677 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTM4677.html#ad80cc6db01007012bbd09b04ab7ce3b0", null ],
    [ "detect", "classLT__PMBusDeviceLTM4677.html#a89c805877e7d5a580d77fc09847058a2", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTM4677.html#ad7eed87187cfa541267f49686cc30828", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTM4677.html#a556e4a5a7a102e534819f42476b9a298", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTM4677.html#a11333d25563f078649ebfb9f5074a71f", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTM4677.html#abf56c3790f06cb6317f4ca3afc520fb5", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTM4677.html#a7a88f016c023bbbc17d95fd5a60ebb48", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTM4677.html#a60c74708ed4b7ba92dc60e9af06f95d1", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTM4677.html#ae641f147ccd86ad6cda7569dc382e59e", null ],
    [ "LT_PMBusDeviceLTM4677", "classLT__PMBusDeviceLTM4677.html#a3cbd1de1333c0c2306f5478066046a11", null ],
    [ "cap_", "classLT__PMBusDeviceLTM4677.html#a40d60c6109ed6830df85b2a341802fa2", null ]
];