var __24xx__iso__spi__delay_8ino =
[
    [ "loop", "__24xx__iso__spi__delay_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "__24xx__iso__spi__delay_8ino.html#a5095ec15d6797f7bf28227f165dea415", null ],
    [ "menu_2_read_differential", "__24xx__iso__spi__delay_8ino.html#a4a5d0562e0e2306d5e55741c8c694840", null ],
    [ "print_prompt", "__24xx__iso__spi__delay_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "__24xx__iso__spi__delay_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "__24xx__iso__spi__delay_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "__24xx__iso__spi__delay_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "delay_EOC", "__24xx__iso__spi__delay_8ino.html#a38313244b306d33c3df18b64cfae9786", null ],
    [ "BUILD_COMMAND_DIFF", "__24xx__iso__spi__delay_8ino.html#aecd2bef5a7980968bf536307e3ecbb14", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "__24xx__iso__spi__delay_8ino.html#a089db05417baced654c68d2539ff1002", null ],
    [ "demo_board_connected", "__24xx__iso__spi__delay_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "MISO_TIMEOUT", "__24xx__iso__spi__delay_8ino.html#a50ab9ab49e31bd464fa19c7959cb6c73", null ],
    [ "reference_voltage", "__24xx__iso__spi__delay_8ino.html#a55ced10a5ef8304b6466cb0566d2b2f9", null ]
];