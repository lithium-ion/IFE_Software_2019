var classNVM =
[
    [ "programWithData", "classNVM.html#a91785adc9662064452ac08e784cf2d9d", null ],
    [ "verifyWithData", "classNVM.html#a3473ad951b30535cb27bb96444e89992", null ],
    [ "NVM", "classNVM.html#a177d92b322451111eba073413fe3da59", null ]
];