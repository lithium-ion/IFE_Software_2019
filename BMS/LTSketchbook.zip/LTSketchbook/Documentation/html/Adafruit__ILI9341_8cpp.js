var Adafruit__ILI9341_8cpp =
[
    [ "DELAY", "Adafruit__ILI9341_8cpp.html#a62249e384b997229a3e2ae74ade334e2", null ],
    [ "MADCTL_BGR", "Adafruit__ILI9341_8cpp.html#a659f0d6f0c258a3d91f882a59dfa76f5", null ],
    [ "MADCTL_MH", "Adafruit__ILI9341_8cpp.html#a6f8b9fad1b5db52b70960b389056f0dd", null ],
    [ "MADCTL_ML", "Adafruit__ILI9341_8cpp.html#a9ecee6d3131d3b4f750b94d5766b998a", null ],
    [ "MADCTL_MV", "Adafruit__ILI9341_8cpp.html#adc23a239d2b6976d53254ef4fc5d1713", null ],
    [ "MADCTL_MX", "Adafruit__ILI9341_8cpp.html#a6d18ed48efb3186877a07d0e81155453", null ],
    [ "MADCTL_MY", "Adafruit__ILI9341_8cpp.html#ab30e6bd24448245df1d60a3e1c4ddbdf", null ],
    [ "MADCTL_RGB", "Adafruit__ILI9341_8cpp.html#acc1e55b52f8a56b7719ab147308a1668", null ],
    [ "spi_begin", "Adafruit__ILI9341_8cpp.html#adeb81aeff267338568a8887bbbbb5739", null ],
    [ "spi_end", "Adafruit__ILI9341_8cpp.html#aa7b1a5deab49d66b0a0cdba4e145cfb8", null ]
];