var Adafruit__FT6206_8h =
[
    [ "TS_Point", "classTS__Point.html", "classTS__Point" ],
    [ "Adafruit_FT6206", "classAdafruit__FT6206.html", "classAdafruit__FT6206" ],
    [ "FT6206_ADDR", "Adafruit__FT6206_8h.html#aa017fe3d67740b30ff6cefc5a1676f94", null ],
    [ "FT6206_DEFAULT_THRESSHOLD", "Adafruit__FT6206_8h.html#a825be9f78eaae219716997947057c09d", null ],
    [ "FT6206_G_FT5201ID", "Adafruit__FT6206_8h.html#aebf00415b4af2deb72fe99d865891f50", null ],
    [ "FT6206_NUM_X", "Adafruit__FT6206_8h.html#a5801e9c557b3fe25dab4e84dd0204a4b", null ],
    [ "FT6206_NUM_Y", "Adafruit__FT6206_8h.html#aa660220e2827da3b207b843aa5eb40ea", null ],
    [ "FT6206_REG_CALIBRATE", "Adafruit__FT6206_8h.html#ad8d52da57ab529cf673c8cc1f8a06484", null ],
    [ "FT6206_REG_CHIPID", "Adafruit__FT6206_8h.html#a978f874e13f801f04493f92ff3f758f3", null ],
    [ "FT6206_REG_FACTORYMODE", "Adafruit__FT6206_8h.html#a24937e3e88b53d2b9515536ae87e1989", null ],
    [ "FT6206_REG_FIRMVERS", "Adafruit__FT6206_8h.html#a6c842589ea779801a2c2eeea4c25a7af", null ],
    [ "FT6206_REG_MODE", "Adafruit__FT6206_8h.html#aea1b85930e294da220e4bbbb32d2cef4", null ],
    [ "FT6206_REG_NUMTOUCHES", "Adafruit__FT6206_8h.html#ab76c4c15ca7be957bb4183418e201180", null ],
    [ "FT6206_REG_POINTRATE", "Adafruit__FT6206_8h.html#abda531d153b141e3d2c66271cbee83ad", null ],
    [ "FT6206_REG_THRESHHOLD", "Adafruit__FT6206_8h.html#a83046a5f75482c97027f8b5425c17ada", null ],
    [ "FT6206_REG_VENDID", "Adafruit__FT6206_8h.html#a3e4b574165b800b485e3e9ad56c8527e", null ],
    [ "FT6206_REG_WORKMODE", "Adafruit__FT6206_8h.html#a892c5e6fa03a08906e50f144103de7ce", null ]
];