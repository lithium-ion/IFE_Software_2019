var classLT__PMBusDeviceLTC2978 =
[
    [ "clearFaultLog", "classLT__PMBusDeviceLTC2978.html#a68bd47f62465a478461b83cea4b0192b", null ],
    [ "detect", "classLT__PMBusDeviceLTC2978.html#aef68676354741bafada4a42ff73f6866", null ],
    [ "disableFaultLog", "classLT__PMBusDeviceLTC2978.html#aa5aa8f665d5913fd16695f070a526e53", null ],
    [ "enableFaultLog", "classLT__PMBusDeviceLTC2978.html#afb52d03c41f51b6a10f0213e4f528a5f", null ],
    [ "getCapabilities", "classLT__PMBusDeviceLTC2978.html#af78d9dcb21ed6125e279afe988c53fff", null ],
    [ "getFaultLog", "classLT__PMBusDeviceLTC2978.html#ac1cebb3e68d15fbbd56050f1f99ec5bc", null ],
    [ "getNumPages", "classLT__PMBusDeviceLTC2978.html#a77eb8eb3e1bae167e3ac65d365f8f3b6", null ],
    [ "getType", "classLT__PMBusDeviceLTC2978.html#a38f36effb0245dfbde9778b720ca7fe8", null ],
    [ "hasCapability", "classLT__PMBusDeviceLTC2978.html#a947aec57db0b5ff0491353ed598431e3", null ],
    [ "hasFaultLog", "classLT__PMBusDeviceLTC2978.html#a09d5f4900c6628db03f1ae62f426cf7d", null ],
    [ "LT_PMBusDeviceLTC2978", "classLT__PMBusDeviceLTC2978.html#a195694e11d99de174d968731ed4cda34", null ],
    [ "cap_", "classLT__PMBusDeviceLTC2978.html#a7685c79c42a22a39b4712e9c75c51571", null ]
];