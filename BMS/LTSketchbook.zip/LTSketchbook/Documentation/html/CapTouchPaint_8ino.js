var CapTouchPaint_8ino =
[
    [ "loop", "CapTouchPaint_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "CapTouchPaint_8ino.html#a635bebcf1bdfa7de6f25c21a01451d64", null ],
    [ "BOXSIZE", "CapTouchPaint_8ino.html#a4f84c7cd953e90b218a9baa12f6e5e35", null ],
    [ "PENRADIUS", "CapTouchPaint_8ino.html#a7c7791e29a4d4da8046b200fb4dc742a", null ],
    [ "TFT_CS", "CapTouchPaint_8ino.html#a5f4d46ae101b77df78010c506601c87c", null ],
    [ "TFT_DC", "CapTouchPaint_8ino.html#a51529307207622c113ff0d584536be13", null ],
    [ "ctp", "CapTouchPaint_8ino.html#a84cfca677d33c75d55e42a3c4227a836", null ],
    [ "currentcolor", "CapTouchPaint_8ino.html#a272870a56ba53cb422f9193dad97f9d3", null ],
    [ "oldcolor", "CapTouchPaint_8ino.html#ab98b07936cc8e82a95130dea7b6c9cd5", null ],
    [ "tft", "CapTouchPaint_8ino.html#a41c3eb6bc5901609f9f976b594e5089f", null ]
];